const secret = "rudramaya"; // Change this if you want a different private word.

const secretInput = document.getElementById("secret");
const unlock = document.getElementById("unlock");
const skip = document.getElementById("skip");
const error = document.getElementById("error");
const gate = document.querySelector(".gate");
const letter = document.getElementById("letter");

function openSite() {
  gate.classList.add("hidden");
  letter.classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function checkSecret() {
  if (secretInput.value.trim().toLowerCase() === secret.toLowerCase()) {
    openSite();
  } else {
    error.textContent = "Hmm… that's not our little word. Try again ♡";
    secretInput.focus();
  }
}

unlock.addEventListener("click", checkSecret);
secretInput.addEventListener("keydown", e => {
  if (e.key === "Enter") checkSecret();
});

skip.addEventListener("click", openSite);

document.querySelectorAll(".choice").forEach(button => {
  button.addEventListener("click", () => {
    const choice = button.dataset.choice;
    const answer = document.getElementById("answer");
    answer.innerHTML = `<strong>It's a ${choice.toLowerCase()} ♡</strong><br>Now all that's left is choosing a day and making the memory.`;
    answer.classList.remove("hidden");
  });
});

document.getElementById("reveal").addEventListener("click", () => {
  document.getElementById("secret-note").classList.remove("hidden");
  document.getElementById("reveal").textContent = "♡";
  document.getElementById("reveal").disabled = true;
});

const hearts = document.querySelector(".hearts");
setInterval(() => {
  const span = document.createElement("span");
  span.textContent = Math.random() > .5 ? "♡" : "✦";
  span.style.left = Math.random() * 100 + "vw";
  span.style.fontSize = (12 + Math.random() * 18) + "px";
  span.style.animationDuration = (7 + Math.random() * 7) + "s";
  hearts.appendChild(span);
  setTimeout(() => span.remove(), 15000);
}, 850);


// Final animated "I love you" screen
const loveScreen = document.getElementById("love-screen");
const revealButton = document.getElementById("reveal");
const closeLove = document.getElementById("close-love");

revealButton.addEventListener("click", () => {
  loveScreen.classList.remove("hidden");
  document.body.style.overflow = "hidden";
});

closeLove.addEventListener("click", () => {
  loveScreen.classList.add("hidden");
  document.body.style.overflow = "";
});
