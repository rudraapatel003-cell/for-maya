# Rudra's Date Invitation ♡

A small romantic-style greeting website inspired by the idea of a private surprise page.

## Run locally
1. Open `index.html` in your browser.
2. The default secret word is `rudramaya`.
3. Edit `script.js` if you want a different word.
4. Edit the text in `index.html` to personalize it.

## GitHub Pages
GitHub Pages can host this as a static website. Put `index.html`, `style.css`, and `script.js` in the repository root and enable Pages for the repository.
